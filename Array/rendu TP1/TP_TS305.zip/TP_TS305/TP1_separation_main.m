clear all; close all; 

clc;

data=load('data.mat');

[nb_sources] = separation(data)

